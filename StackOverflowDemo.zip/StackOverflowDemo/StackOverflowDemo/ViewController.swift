//
//  ViewController.swift
//  StackOverflowDemo
//
//  Created by Dinesh Sharma on 15/10/19.
//  Copyright © 2019 Ranosys. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    lazy var contentViewSize = CGSize(width: view.frame.width, height:1500)

    lazy var contView : UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.frame.size = contentViewSize
        return view
    }()
    lazy var scrollView : UIScrollView = {
        let view = UIScrollView(frame: .zero)
        view.backgroundColor = .white
        view.contentSize = contentViewSize
        view.frame = self.view.bounds
        view.autoresizingMask = .flexibleHeight
        return view
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
       scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        scrollView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        scrollView.heightAnchor.constraint(equalTo: view.heightAnchor).isActive = true

        contView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contView)
        contView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        contView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        contView.heightAnchor.constraint(equalToConstant: 1500).isActive = true
        //declare a button to update height
        let btn = UIButton()
        btn.frame = CGRect(x: 100, y: 100, width: 100, height: 100)
        btn.backgroundColor = .black
        btn.addTarget(self, action: #selector(update), for: .touchUpInside)
        contView.addSubview(btn)
    }
   
        var bool = true
       @objc func update(){
        
           if bool {
               contentViewSize = CGSize(width: view.frame.width, height: 7000)

               scrollView.contentSize = contentViewSize
               contView.frame.size = contentViewSize


               view.layoutIfNeeded()
               scrollView.layoutIfNeeded()
               contView.layoutIfNeeded()




           } else {

               contentViewSize = CGSize(width: view.frame.width, height: 1500)

               contView.frame.size = contentViewSize
               scrollView.contentSize = contentViewSize
               view.layoutIfNeeded()

               scrollView.layoutIfNeeded()
               contView.layoutIfNeeded()

           }
           bool = !bool

       }
    
}

